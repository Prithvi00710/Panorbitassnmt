import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LandingpageComponent } from './landingpage/landingpage.component';
import { ComoingsoonComponent } from './comoingsoon/comoingsoon.component';
import { ProfileComponent } from './profile/profile.component';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class ModulesModule { }
