import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comoingsoon',
  templateUrl: './comoingsoon.component.html',
  styleUrls: ['./comoingsoon.component.css']
})
export class ComoingsoonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
